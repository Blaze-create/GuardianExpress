
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="a404-wrapper">
            <div class="row errormissing">
                <div class="col">
                    <div class="bigError">
                        <div class="first-one">
                            <div class="glitch-wrapper">
                                <div class="glitch" data-text="404">404</div>
                            </div>
                        </div>
                        <div class="second-one">
                            <div class="glitch-wrapper">
                                <div class="glitch" data-text="404">404</div>
                            </div>
                        </div>

                    </div>
                    <div class="error-message">
                        <div class="title">
                            Page Missing!
                        </div>
                        <div class="message">
                            But no worries! Our ostrich is looking everywhere while you wait safely.
                        </div>
                        <div class="go-home-btn">
                            <a href="<?php echo e(route('home')); ?>">
                                <button class="btn">
                                    Go Home
                                </button>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="col img">
                    <img src="<?php echo e(asset('img/404.png')); ?>" alt="">
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\charl\Documents\Projects\laravel\GuardianExpresss\resources\views/errors/404.blade.php ENDPATH**/ ?>