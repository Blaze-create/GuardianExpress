
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="login-wrapper">
            <div class="login-form">
                <form action="<?php echo e(route('getReport')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="input-grp">
                        <label for="email">Describe the problem*:</label>
                        <small style="color: gray;">Please provide as much detail as possible so we can better identify
                            the problem.</small>
                        <textarea name="report" id="" rows="8"></textarea>
                    </div>
                    <div class="submit-grp">
                        <button type="submit">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\charl\Documents\Projects\laravel\GuardianExpresss\resources\views/report.blade.php ENDPATH**/ ?>